<!DOCTYPE html>
<html>
<body>

<?php
function familyName($fname, $year) {
  echo "$fname shah. Born in $year <br>";
}

familyName("Helly","2002");
familyName("Sweta","2004");
familyName("keya","2003");
?>

</body>
</html>
